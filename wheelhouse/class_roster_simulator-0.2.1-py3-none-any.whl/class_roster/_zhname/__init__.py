"""class_roster._zhname — 内置的中国学生基础信息生成模块。

本模块是 `alt_generate_zh_name`（https://github.com/ashida2016/alt_generate_zh_name）
的内置副本，采用 Apache-2.0 许可证（见本目录 LICENSE 文件）。

Vendoring 原因：原包未发布到 PyPI，且以 ``@ git+https`` 直接 URL 依赖的形式
引用，会导致无法访问 github.com 的构建环境（如内网 Docker 构建）安装失败。
将代码收编进本包后，``class-roster-simulator`` 不再依赖任何 git 源。

对外接口保持不变：``generate()`` 的签名与 ``pd.DataFrame`` 返回值
（列：``["姓名", "性别", "生日"]``）与原包完全一致。
"""

from class_roster._zhname.generator import generate

__version__ = "0.2.2"

__all__ = ["generate"]
